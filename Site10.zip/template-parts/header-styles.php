<!-- header styles -->

<?php
   $localFonts = apply_filters('get_local_fonts', '');
?>
<?php if ($localFonts) : ?> 
   <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/<?php echo $localFonts; ?>" media="screen" type="text/css" />
<?php else : ?>
   <?php endif; ?>
<link id="u-google-font" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i|Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i">
<style>.u-header .u-section-row-1 {
  background-image: none;
}
.u-header .u-sheet-1 {
  min-height: 104px;
}
.u-header .u-search-1 {
  width: 250px;
  min-height: 38px;
  margin: 24px auto 0;
}
.u-header .u-social-icons-1 {
  white-space: nowrap;
  height: 27px;
  min-height: 16px;
  width: 101px;
  min-width: 68px;
  margin: -32px 53px 48px auto;
}
.u-header .u-icon-1 {
  color: rgb(59, 89, 152) !important;
}
.u-header .u-icon-2 {
  color: rgb(85, 172, 238) !important;
}
.u-header .u-icon-3 {
  color: rgb(197, 54, 164) !important;
}
@media (max-width: 1199px) {
  .u-header .u-search-1 {
    height: auto;
  }
}
@media (max-width: 575px) {
  .u-header .u-search-1 {
    margin-top: 77px;
  }
  .u-header .u-social-icons-1 {
    margin-top: -85px;
  }
}
.u-header .u-sheet-2 {
  min-height: 140px;
}
.u-header .u-image-1 {
  width: 102px;
  height: 136px;
  margin: 2px auto 0 0;
}
.u-header .u-logo-image-1 {
  width: 100%;
  height: 100%;
}
.u-header .u-menu-1 {
  margin: -87px 24px 37px auto;
}
.u-header .u-nav-1 {
  font-size: 1rem;
  letter-spacing: 0px;
  font-weight: 700;
}
.u-block-5c67-22 {
  font-size: 1rem;
  letter-spacing: 0px;
  font-weight: 700;
}
.u-header .u-nav-2 {
  font-size: 1rem;
  letter-spacing: 0px;
  font-weight: 700;
}
.u-block-5c67-23 {
  font-size: 1rem;
  letter-spacing: 0px;
  font-weight: 700;
}</style>
